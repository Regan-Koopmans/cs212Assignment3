public class Node
{
  public Node next = null;
  public BStarTreeNode elem;

  public Node(BStarTreeNode node)
  {
    elem = node;
  }
}
